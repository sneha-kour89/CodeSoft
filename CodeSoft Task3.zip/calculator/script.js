let displayValue = '0';
    let pendingOperation = null;
    let firstOperand = null;
    let secondOperand = null;

    function updateDisplay() {
        document.getElementById('display').innerText = displayValue;
    }

    function appendNumber(number) {
        if (displayValue === '0' || displayValue === 'Infinity') {
            displayValue = '';
        }
        displayValue += number;
        updateDisplay();
    }

    function clearDisplay() {
        displayValue = '0';
        updateDisplay();
    }

    function operation(operator) {
        if (pendingOperation !== null) {
            calculate();
        }
        firstOperand = parseFloat(displayValue);
        pendingOperation = operator;
        clearDisplay();
    }

    function calculate() {
        if (pendingOperation === null || pendingOperation === '=') {
            return;
        }
        secondOperand = parseFloat(displayValue);
        switch (pendingOperation) {
            case '+':
                displayValue = firstOperand + secondOperand;
                break;
            case '-':
                displayValue = firstOperand - secondOperand;
                break;
            case '*':
                displayValue = firstOperand * secondOperand;
                break;
            case '/':
                if (secondOperand === 0) {
                    displayValue = 'Infinity';
                } else {
                    displayValue = firstOperand / secondOperand;
                }
                break;
        }
        updateDisplay();
        pendingOperation = '=';
    }
